"use strict";
exports.__esModule = true;
var cruddl_1 = require("cruddl");
var project = new cruddl_1.Project([{
        name: 'schema.graphqls',
        body: "\n    type Movie @rootEntity {\n      title: String\n      actors: Actor @relation\n    }\n    \n    type Actor @rootEntity {\n      name: String\n      movies: Movie @relation(inverseOf: \"actors\")\n    }"
    }, {
        name: 'permission-profiles.json',
        body: JSON.stringify({
            permissionProfiles: {
                "default": {
                    permissions: [{
                            roles: ['users'],
                            access: 'readWrite'
                        }]
                }
            }
        })
    }]);
exports.project = project;
exports["default"] = project;
