import { Project } from 'cruddl';
const project = new Project([{
  name: 'schema.graphqls',
  body: `
    type Movie @rootEntity {
      title: String
      actors: Actor @relation
    }
    
    type Actor @rootEntity {
      name: String
      movies: Movie @relation(inverseOf: "actors")
    }`
}, {
  name: 'permission-profiles.json',
  body: JSON.stringify({
    permissionProfiles: {
      default: {
        permissions: [{
          roles: ['users'],
          access: 'readWrite'
        }]
      }
    }
  })
}]);

 export default project;
export { project };