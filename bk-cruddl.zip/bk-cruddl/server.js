"use strict";
exports.__esModule = true;
var graphql_yoga_1 = require("graphql-yoga");
var dbConnect_1 = require("./dbConnect");
var testModel_1 = require("./model/testModel");
var schema = testModel_1.project.createSchema(dbConnect_1.db);
dbConnect_1.db.updateSchema(testModel_1.project.getModel()); // create missing collections
var server = new graphql_yoga_1.GraphQLServer({ schema: schema, context: function () { return ({ authRoles: ['users'] }); } });
server.start(function () { return console.log('Server is running on http://localhost:4000/'); });
