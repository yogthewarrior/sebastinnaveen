import { GraphQLServer } from 'graphql-yoga';
import {db} from './dbConnect';
import {project} from './model/testModel';
const schema = project.createSchema(db);
db.updateSchema(project.getModel()); // create missing collections
const server = new GraphQLServer({ schema, context: () => ({ authRoles: [ 'users' ]}) });
server.start(() => console.log('Server is running on http://localhost:4000/'));