import React, { Component } from 'react';
import logo from './logo.svg';
import test from './test.json';
import './App.css';
import axios from 'axios';

class App extends Component {
  constructor(props) {
    super(props);
    
    this.state = {
      kind: '',
      data: []
    };
  }
  
  componentDidMount(){
    axios
      .get('https://www.reddit.com/r/reactjs.json')
      .then(({ data })=> {
      	this.setState({ 
          kind: data.kind, 
          data: data.data.children
        });
      })
      .catch((err)=> {})
  }
      
  render() {
    const child = this.state.data.map((el, index) => {
      return <div key={index}>
        <p>Title - { el.data.title }</p>
        <p>Author - { el.data.author }</p>
      </div>
    });


    return (

      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Welcome to Hackathon App</h1>
        </header>
        <h5>Signin with Socialmedia</h5>

        <div class="sociable clearfix">
            <p>
               <a href="javascript:void(0);" class="facebook" onclick=""> 
            
             
              <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                <g id="Fb" fill="#FFFFFF" fill-rule="nonzero">
                  <path d="M1.55086906,16 L4.65504056,16 L4.65504056,7.99913616 L6.72584009,7.99913616 L7,5.24263039 L4.65504056,5.24263039 L4.65828505,3.8622179 C4.65828505,3.14350502 4.72236385,2.75823345 5.69084589,2.75823345 L6.98539977,2.75823345 L6.98539977,0 L4.91378911,0 C2.42607184,0 1.55086906,1.33808444 1.55086906,3.58665371 L1.55086906,5.24176655 L0,5.24176655 L0,7.99913616 L1.55086906,7.99913616 L1.55086906,16 L1.55086906,16 Z"></path>
                </g>
              </g>
             
              </a> 
              <a href="https://www.techgig.com/social_connect.php?provider=Google&amp;user_type=external&amp;return_url=https://www.techgig.com/home" class="google">
              
              
              <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                <g id="Google" fill="#FFFFFF" fill-rule="nonzero">
                  <path d="M6.34313725,5.21505792 L6.34313725,7.78996139 C6.34313725,7.78996139 8.77941176,7.78494208 9.7745098,7.78494208 C9.23529412,9.45135135 8.40196078,10.3598456 6.34313725,10.3598456 C4.25980392,10.3598456 2.6372549,8.63320463 2.6372549,6.5 C2.6372549,4.36679537 4.26470588,2.64015444 6.34313725,2.64015444 C7.44607843,2.64015444 8.15686275,3.03667954 8.80882353,3.58880309 C9.33333333,3.05173745 9.28921569,2.97644788 10.6176471,1.69150579 C9.49019608,0.642471042 7.99019608,0 6.34803922,0 C2.84313725,0 0,2.91119691 0,6.5 C0,10.0888031 2.84313725,13 6.34803922,13 C11.5882353,13 12.8676471,8.32702703 12.4411765,5.21505792 L6.34313725,5.21505792 Z M17.7843137,5.34054054 L17.7843137,3.08687259 L16.2156863,3.08687259 L16.2156863,5.34054054 L13.9558824,5.34054054 L13.9558824,6.94671815 L16.2156863,6.94671815 L16.2156863,9.26061776 L17.7843137,9.26061776 L17.7843137,6.94671815 L19.9852941,6.94671815 L19.9852941,5.34054054 L17.7843137,5.34054054 Z"></path>
                </g>
              </g>

             </a>
             
              <a href="https://www.techgig.com/social_connect.php?provider=LinkedIn&amp;user_type=external&amp;return_url=https://www.techgig.com/home" class="linkedin">
              
             
              <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                <g id="Linkedin" fill="#FFFFFF" fill-rule="nonzero">
                  <path d="M0.242307692,4.64864865 L3.13923077,4.64864865 L3.13923077,14 L0.242307692,14 L0.242307692,4.64864865 Z M1.69615385,0 C2.62230769,0 3.37615385,0.756756757 3.37615385,1.68648649 C3.37615385,2.61621622 2.62230769,3.37297297 1.69615385,3.37297297 C0.764615385,3.37297297 0.0161538462,2.61621622 0.0161538462,1.68648649 C0.0161538462,0.756756757 0.764615385,0 1.69615385,0 Z M4.95923077,4.64864865 L7.73230769,4.64864865 L7.73230769,5.92972973 L7.77,5.92972973 C8.15769231,5.19459459 9.1,4.42162162 10.5107692,4.42162162 C13.44,4.42162162 13.9838462,6.35675676 13.9838462,8.87567568 L13.9838462,14 L11.0923077,14 L11.0923077,9.45405405 C11.0923077,8.36756757 11.0761538,6.97297297 9.59,6.97297297 C8.08230769,6.97297297 7.85615385,8.15675676 7.85615385,9.37297297 L7.85615385,14 L4.96461538,14 L4.95923077,4.64864865 Z"></path>
                </g>
              </g>
              </a>
           </p>
          </div>
         
          <h5>Signup with Email</h5>



          
          <div id="newsletter-form" class="form1">
                     
			    <input type="text" placeholder="Enter Email" class="form-control" id="register_email" name="email" maxlength="200" required="" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$"/>
          <input type="button" class="btn button1" value="Continue" onclick="return Tg_CommonFunction.validateEmailSignup();"/>
        

        </div>


        <p className="App-intro">
        <div>
      <p>{ this.state.kind }</p>
      <div>{ child }</div>
    </div>

        </p>
      </div>
    );
  }
}

export default App;
