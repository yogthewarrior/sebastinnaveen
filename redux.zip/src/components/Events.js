import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { fetchPosts } from '../actions/postActions';

class Events extends Component {
    componentWillMount() {
       console.log( this.props.type);
      }
    

    render() {
        return(
<div>
        <h1>{this.props.type}</h1>
    
      </div>

        )
    }

}

export default Events;